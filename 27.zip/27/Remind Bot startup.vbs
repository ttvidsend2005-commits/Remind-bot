Set WShell = CreateObject("WScript.Shell")
WShell.Run chr(34) & "C:\Users\WD\Desktop\System\bot\bellbot\Remind Bot startup.bat" & chr(34), 0
Set WShell = Nothing