@echo off
cd /d "C:\Users\WD\Desktop\System\bot\bellbot"
node index.js
pause