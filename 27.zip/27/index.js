const { Readable } = require('stream');
const googleTTS = require('google-tts-api');
const { Client, GatewayIntentBits, Events } = require('discord.js');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  getVoiceConnection,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  StreamType,
  entersState,
} = require('@discordjs/voice');

// ====== SETTINGS (change these 3 values) ======
const TOKEN = 'MTU2ODE1MDUxNjU3ODUyNTMwNQ.GUI30g.jpHHq9AQYPfmY8TwNfU_U31vPsluiL96y77Ong';
const WAITING_VC_ID = '1566455954650828910';
const PRIVATE_VC_ID = '1146381098482409472';
const MESSAGE = (name) => `${name} is waiting for private voice`;
const LANGUAGE = 'en';
// ===============================================

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates],
});

// Queue so that if 2 people join together, each name is announced one by one
const queue = [];
let busy = false;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

client.once(Events.ClientReady, (c) => {
  console.log(`Logged in as ${c.user.tag}`);
});

// Keep only normal letters, numbers and spaces. Emojis and symbols are removed.
function cleanName(name) {
  const cleaned = name
    .normalize('NFKC')                 // fancy fonts -> normal letters
    .replace(/[^\p{L}\p{N}\s]/gu, ' ') // remove emojis and symbols
    .replace(/\s+/g, ' ')
    .trim();
  return cleaned || 'Someone';
}

async function getTTSBuffer(text) {
  const url = googleTTS.getAudioUrl(text, {
    lang: LANGUAGE,
    slow: false,
    host: 'https://translate.google.com',
  });
  const res = await fetch(url);
  if (!res.ok) throw new Error(`TTS request failed: ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

async function announce(guild, member) {
  // Skip if the person already left the waiting channel
  if (member.voice.channelId !== WAITING_VC_ID) return;

  const privateVc = await guild.channels.fetch(PRIVATE_VC_ID).catch(() => null);
  if (!privateVc || !privateVc.isVoiceBased()) {
    console.error('Private VC not found. Check PRIVATE_VC_ID.');
    return;
  }

  // Only announce if a real person is inside the private VC
  const humans = privateVc.members.filter((m) => !m.user.bot);
  if (humans.size === 0) return;

  const audio = await getTTSBuffer(MESSAGE(cleanName(member.displayName)));

  const connection = joinVoiceChannel({
    channelId: privateVc.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
  });

  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 15_000);
    await sleep(500); // small delay so the first word isn't cut off

    const player = createAudioPlayer();
    connection.subscribe(player);

    const resource = createAudioResource(Readable.from([audio]), {
      inputType: StreamType.Arbitrary,
    });
    player.play(resource);

    await entersState(player, AudioPlayerStatus.Playing, 10_000);
    await entersState(player, AudioPlayerStatus.Idle, 30_000);

    player.stop();
  } finally {
    connection.destroy();
  }
}

async function processQueue() {
  if (busy) return;
  busy = true;
  while (queue.length) {
    const { guild, member } = queue.shift();
    try {
      await announce(guild, member);
    } catch (err) {
      console.error('Error:', err);
      getVoiceConnection(guild.id)?.destroy();
    }
  }
  busy = false;
}

client.on(Events.VoiceStateUpdate, (oldState, newState) => {
  // Only when someone newly joins the waiting channel
  if (newState.channelId !== WAITING_VC_ID) return;
  if (oldState.channelId === WAITING_VC_ID) return;
  if (newState.member?.user.bot) return;

  queue.push({ guild: newState.guild, member: newState.member });
  processQueue();
});

client.on('error', (err) => console.error('Client error:', err));
process.on('unhandledRejection', (err) => console.error('Unhandled:', err));

client.login(TOKEN);